package pe.org.chaclacayo.pyfinal2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pyfinal2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
