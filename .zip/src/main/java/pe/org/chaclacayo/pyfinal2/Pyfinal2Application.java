package pe.org.chaclacayo.pyfinal2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pyfinal2Application {

	public static void main(String[] args) {
		SpringApplication.run(Pyfinal2Application.class, args);
	}

}
